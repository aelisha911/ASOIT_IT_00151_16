<!DOCTYPE html>
<html>
<body>
<form method="post">
    Enter first number:
<input type="number" name="number1"/><br><br>
Enter Second Number:
<input type="number" name="number2"/><br><br>
<input type="submit" name="submit" value="Add"/><br><br>


</form>
<?php
if(isset($_post['submit']))
{
    $number1=$_post['number1'];
    $number2=$_post['number2'];
    $sum=$number1+$number2;
    echo "The Sum Of $number1 and $number2 is:".$sum;

}
// $x = 10;  
// $y = 6;
// echo "1.addition
//     2.substraction
//     3.multiplication
//     4.division";
// echo "enter your choice:";
// echo "addition=",$x + $y;
// echo "sub=",$x - $y;
// echo "mul=",$x * $y;
// echo "div=",$x / $y;
?>  

</body>
</html>
