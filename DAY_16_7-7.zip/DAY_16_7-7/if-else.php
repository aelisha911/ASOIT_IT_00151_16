<!DOCTYPE html>
<html>
<body>

<?php
$t =30;

if ($t < "20") {
  echo "Have a good day!";
} else {
  echo "Have a good night!";
}
?>
 
</body>
</html>